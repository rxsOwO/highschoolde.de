<?php

$serverName = "localhost";
$dBUsername = "u538187427_highschooldede";
$dBPassword = "1ebivTs@";
$dBName = "u538187427_highschooldede";

$conn = mysqli_connect($serverName, $dBUsername, $dBPassword, $dBName);

if (!$conn) {
    die("Connection Failed: " . mysqli_connect_error());
}