<?php
session_start();

    
    $data = isset($_REQUEST['myScore'])?$_REQUEST['myScore']:"";
    $windmillData = isset($_REQUEST['myWindmills'])?$_REQUEST['myWindmills']:"";
    $slimeGunData = isset($_REQUEST['mySlimeGuns'])?$_REQUEST['mySlimeGuns']:"";
    $giraffeData = isset($_REQUEST['myGiraffes'])?$_REQUEST['myGiraffes']:"";
    $userid = $_SESSION["userid"];

    echo $data;

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
if (isset($_SESSION['useruid'])) {
    saveScore($conn, $userid, $data, $windmillData, $slimeGunData, $giraffeData);
}
else {
    header("location: ../login.php?error=notloggedin");
    exit();
}