<?php 
    session_start();
?>

<!DOCTYPE html>

<html>
    <head>
        <title>highschoolde.de</title>
        <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
        <link rel="shortcut icon" type="image/png" href="jesse.png"/>
        <meta name="viewport" content="width=device_width, initial-scale=1.0">
        
    </head>
    <body> 
        <p style="font-family: Arial, Helvetica, sans-serif">for business, email joemama@highschoolde.de</p>
        <header class="mainHeader">
       
        <h1>The Official Website For All Things</h1>
        </header>
        <hr>
        <a href="jesse.php"><img src="jesse.png" alt="uwu" width="400" height="400" class="jesse"></a>
        <?php 
            if (isset($_SESSION["useruid"])) {
                $userid = $_SESSION["userid"];
                require_once 'includes/dbh.inc.php';
                require_once 'includes/functions.inc.php';
                $jesseEnd = loadJesseEnd($conn, $userid);
                echo "<p class='signup'>hello ". $_SESSION["useruid"] ."</p>";
                echo "<a href='includes/logout.inc.php'><h2 class='login'>log out</h2></a>";
                if (!empty($jesseEnd)) {
                    echo "<a href='james/james.php'><h2 class='login' style='color:red;'>james</h2></a>";
                }
            }
            else {
                echo "<a href='signup.php'><h2 class='signup'>sign up</h2></a>";
                echo "<a href='login.php'><h2 class='login'>log in</h2></a>";
            }
        ?>
        <a href='leaderboard.php'><h2 class='signup'>leaderboard</h2></a>

        </script>
    </body>
<html>