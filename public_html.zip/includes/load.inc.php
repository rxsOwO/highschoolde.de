<?php
session_start();
    
    $cool = $_SESSION["userid"];
    $userid = $_SESSION["userid"];

    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';

if (isset($_SESSION['useruid'])) {
    $loadData = array(loadScore($conn, $userid), loadWindmills($conn, $userid), loadSlimeGuns($conn, $userid), loadGiraffes($conn, $userid));
    echo '' . implode(', ', $loadData) . '';

}
else {
    header("location: ../login.php?error=notloggedin");
    exit();
}