<?php
    session_start();

    $userid = $_SESSION["userid"];
    require_once '../includes/dbh.inc.php';
    require_once '../includes/functions.inc.php';
    
    $jesseEnd = loadJesseEnd($conn, $userid);
    $_POST['jesseEndCool'] = $jesseEnd;
    if (!empty($jesseEnd)) {
        echo '<html><head><title>cutscene</title><link rel="shortcut icon" type="image/png" href="../jesse.png"/></head><body><button onclick="video.play()">make cutscene go</button><video width="100%" height="100%" src="reedfight.mp4" autoplay id="moemoekyun"></video></body><script>const video = document.getElementById("moemoekyun");video.onended = function(e) {window.location.href = "../james/james.php";};</script></html>';
    }
    else {
        header("location: ../index.php");
        exit();
    }
?>