<?php

?>

<html>
    <head>
        <title>log in</title>
        <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
        <link rel="shortcut icon" type="image/png" href="jesse.png"/>
    </head>
    <body>
        <header class="mainHeaderAcc">
        <h1 style="margin-top: 35px;">log in :)</h1>
        </header>
        <hr>
        <form action="includes/login.inc.php" method="post">
            <input type="text" name="uid" placeholder="username">
            <input type="password" name="pwd" placeholder="password">
            <button type="submit" name="submit">Log In</button>
        </form>
        <?php
            if (isset($_GET["error"])) {
                if ($_GET["error"] == "emptyinput") {
                    echo "<p class='errortext'>you forgot something</p>";
                }
                else if ($_GET["error"] == "wronglogin") {
                    echo "<p class='errortext'>incorrect username/password</p>";
                }
            }
        ?>
    </body>
<html>