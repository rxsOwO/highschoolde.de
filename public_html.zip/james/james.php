<?php
    session_start();

    $userid = $_SESSION["userid"];
    require_once '../includes/dbh.inc.php';
    require_once '../includes/functions.inc.php';
    $jesseEnd = loadJesseEnd($conn, $userid);
    if (!empty($jesseEnd)) {
        echo 'cumming soon :)';

    }
    else {
        header("location: ../index.php");
        exit();
    }
?>