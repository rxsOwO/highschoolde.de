<?php

function emptyInputSignup($username, $pwd){
    $result;
    if (empty($username) || empty($pwd)) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}
function invalidUid($username) {
    $result;
    if (!preg_match("/^[a-zA-Z0-9]*$/", $username)) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}

function uidExists($conn, $username){
    $sql = "SELECT * FROM users WHERE usersUid = ?;";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../signup.php?error=stmtfailed");
        exit();
    }

    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);

    $resultData = mysqli_stmt_get_result($stmt);

    if ($row = mysqli_fetch_assoc($resultData)) {
        return $row;
    }
    else {
        $result = false;
        return $result;
    }

    mysqli_stmt_close($stmt);
}
function createUser($conn, $username, $pwd) {
    $sql = "INSERT INTO users (usersUid, usersPwd) VALUES (?, ?);";
    $stmt = mysqli_stmt_init($conn);
    if (!mysqli_stmt_prepare($stmt, $sql)) {
        header("location: ../signup.php?error=stmtfailed");
        exit();
    }

    $hashedPwd = password_hash($pwd, PASSWORD_DEFAULT);

    mysqli_stmt_bind_param($stmt, "ss", $username, $hashedPwd);
    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);
    header("location: ../signup.php?error=none");
    exit();
}
function emptyInputLogin($username, $pwd){
    $result;
    if (empty($username) || empty($pwd)) {
        $result = true;
    }
    else {
        $result = false;
    }
    return $result;
}
function loginUser($conn, $username, $pwd) {
    $uidExists = uidExists($conn, $username);

    if ($uidExists === false) {
        header("location: ../login.php?error=wronglogin");
        exit();
    }

    $pwdHashed = $uidExists["usersPwd"];
    $checkPwd = password_verify($pwd, $pwdHashed);

    if ($checkPwd === false) {
        header("location: ../login.php?error=wronglogin");
        exit();
    }
    else if ($checkPwd === true) {
        session_start();
        $_SESSION["userid"] = $uidExists["usersId"];
        $_SESSION["useruid"] = $uidExists["usersUid"];
        header("location: ../index.php");
        exit();
    }
}
function saveScore($conn, $userid, $data, $windmillData, $slimeGunData, $giraffeData){
    if (isset($userid)) {
        echo $data;
        $sql = "UPDATE users SET usersScore = (?), usersWindmills = (?), usersSlimeGuns = (?), usersGiraffes = (?) WHERE usersId = (?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../jesse.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "sssss", $data, $windmillData, $slimeGunData, $giraffeData, $userid);
        mysqli_stmt_execute($stmt);
    
        mysqli_stmt_close($stmt);
        exit();
    }
    else {
        header("location: ../login.php?error=notloggedin");
        exit();
    }

}
function saveJesseEnd($conn, $userid, $data, $windmillData, $slimeGunData, $giraffeData, $jesseEndData){
    if (isset($userid)) {
        echo $data;
        $sql = "UPDATE users SET usersScore = (?), usersWindmills = (?), usersSlimeGuns = (?), usersGiraffes = (?), usersJesseEnd = (?) WHERE usersId = (?);";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../jesse.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "ssssss", $data, $windmillData, $slimeGunData, $giraffeData, $jesseEndData, $userid);
        mysqli_stmt_execute($stmt);
    
        mysqli_stmt_close($stmt);
        exit();
    }
    else {
        header("location: ../login.php?error=notloggedin");
        exit();
    }

}
function loadScore($conn, $userid) {
    if (isset($userid)) {
        $sql = "SELECT usersScore FROM users WHERE usersId = (?)";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../jesse.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "s", $userid);

        mysqli_stmt_execute($stmt);
        $resultData = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($resultData)['usersScore'];
        mysqli_stmt_close($stmt);
        exit();

    }
    
    else {
        header("location: ../login.php?error=notloggedin");
        exit();
    }
}
function loadWindmills($conn, $userid) {
    if (isset($userid)) {
        $sql = "SELECT usersWindmills FROM users WHERE usersId = (?)";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../jesse.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "s", $userid);

        mysqli_stmt_execute($stmt);
        $resultData = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($resultData)['usersWindmills'];
        mysqli_stmt_close($stmt);
        exit();

    }
    
    else {
        header("location: ../login.php?error=notloggedin");
        exit();
    }
}
function loadSlimeGuns($conn, $userid) {
    if (isset($userid)) {
        $sql = "SELECT usersSlimeGuns FROM users WHERE usersId = (?)";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../jesse.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "s", $userid);

        mysqli_stmt_execute($stmt);
        $resultData = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($resultData)['usersSlimeGuns'];
        mysqli_stmt_close($stmt);
        exit();

    }
    
    else {
        header("location: ../login.php?error=notloggedin");
        exit();
    }
}
function loadGiraffes($conn, $userid) {
    if (isset($userid)) {
        $sql = "SELECT usersGiraffes FROM users WHERE usersId = (?)";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../jesse.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "s", $userid);

        mysqli_stmt_execute($stmt);
        $resultData = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($resultData)['usersGiraffes'];
        mysqli_stmt_close($stmt);
        exit();

    }
    
    else {
        header("location: ../login.php?error=notloggedin");
        exit();
    }
}
function loadJesseEnd($conn, $userid) {
    if (isset($userid)) {
        $sql = "SELECT usersJesseEnd FROM users WHERE usersId = (?)";
        $stmt = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($stmt, $sql)) {
            header("location: ../jesse.php?error=stmtfailed");
            exit();
        }
        mysqli_stmt_bind_param($stmt, "s", $userid);

        mysqli_stmt_execute($stmt);
        $resultData = mysqli_stmt_get_result($stmt);
        return mysqli_fetch_assoc($resultData)['usersJesseEnd'];
        mysqli_stmt_close($stmt);
        exit();

    }
    
    else {
        header("location: ../login.php?error=notloggedin");
        exit();
    }
}

