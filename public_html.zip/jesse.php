<?php 
    session_start();
?>

<!DOCTYPE html>

<html>
    <head>
        <title>jesse's mind</title>
        <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
        <link rel="shortcut icon" type="image/png" href="jesse.png"/>
        <meta name="viewport" content="width=device_width, initial-scale=1.0">
        <script>var isWindmillClicked = false;</script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    </head>
    <body>
        <div style="width: 100%;" id="saveAndLoadDiv">
            <button class="saveAndLoad" onclick="$.ajax({url: 'includes/save.inc.php',type: 'POST',data:{'myScore':score,'myWindmills': multiplier, 'mySlimeGuns':slimeGunMultiplier, 'myGiraffes': giraffeMultiplier}}).done(function(data) {console.log(data);});">save score</button>
            <button class="saveAndLoad" onclick="$.get( 'includes/load.inc.php', { 'myScore': score } ).done(function( data ) { const dataArray = data.split(','); score = parseInt(dataArray[0]); multiplier = parseInt(dataArray[1]); slimeGunMultiplier = parseInt(dataArray[2]); giraffeMultiplier = parseInt(dataArray[3]); if(parseInt(dataArray[1]) >= 1) {isWindmillClicked = true;}; if(parseInt(dataArray[2]) >= 1) {isSlimeGunClicked = true;}; if(parseInt(dataArray[3]) >= 1) {isGiraffeClicked = true;}; }); ">load score</button>
            <button class='saveAndLoad' onclick="if(music.paused && !music.ended) {music.play();} else {music.pause();}">music player</button>
        </div>
        <!--<audio loop controls autoplay><source src="music.mp3" type="audio/mpeg">Your browser does not support the audio tag.</audio>-->
        <p id="test">
        <header class="mainHeaderJesse">
        <h1>jesse's mind: the secrets are within</h1>
        </header>
        <hr>
        <p class="funny">Sadness Points: <span id="score">0</span></p>
        <img src="slime_gun.gif" alt="slime gun is here" width="106" height="106" id="slimegunhit" class="invisibleWindmill" style="margin-left:39.5%; margin-top: 8%;">
        <img src="windmill.gif" alt="windmill is here" width="106" height="106" id="windmillhit" class="invisibleWindmill">
        <img src="giraffe.gif" alt="giraffe is here" width="106" height="106" id="giraffehit" class="invisibleWindmill" style="margin-left:41%;">
        <img src="sandpaper.png" alt="uwu" width="400" height="400" class="reed" onclick="addToScore(1);">
        <p class="funny">Sadness Points Per Second: <span id="CPPS">0</span></p>
        <div class="relative">
            <img src="windmill_frame.png" alt="windmill is here" width="100" height="50%" class="windmillFrame">
            <button id="windmill" class="center" onclick="windmillButtonFunction();"><span id="windmillButtonText" class="windmillButtonText">Locked</span></button>
        </div>
        <div class="relative">
            <button id="slimegun" class="center" onclick="slimeGunButtonFunction();" style="left:45%;"><span id="slimeGunButtonText" class="slimeGunButtonText">Locked</span></button>
            <img src="slime_gun_frame.png" alt="slime gun is here" class="slimeGunFrame" width="100" height="50%">
        </div>
        <div class="relative">
            <button id="giraffe" class="center" onclick="giraffeButtonFunction();" style="left:45%;"><span id="giraffeButtonText" class="giraffeButtonText">Locked</span></button>
            <img src="giraffe_frame.png" alt="giraffe is here" class="giraffeFrame" width="100" height="50%">
        </div>
        <div class="relative">
            <button id="sword" class="center" onclick="swordButtonFunction();" style="left:45%;"><span id="swordButtonText" class="giraffeButtonText">Locked</span></button>
            <img src="sword_frame.png" alt="sword is here" class="giraffeFrame" width="100" height="50%">
        </div>
        
        <script>
            const music = new Audio('music.mp3');
            music.loop =true;
            var score = 0;
            var CPPS = 0;
            var multiplier = 0;
            var slimeGunMultiplier = 0;
            var giraffeMultiplier = 0;
            var isWindmillClicked = false;
            var isSlimeGunClicked = false;
            var isGiraffeClicked = false;
            var isSwordClicked = false;

            setInterval(ClicksForYou,1000);
            setInterval(normalStuff,1);

            function addToScore(amount) {
                score = score + amount;
                document.getElementById("score").innerHTML = score.toLocaleString();
                document.getElementById("CPPS").innerHTML = CPPS.toLocaleString();
            }
            
            
            function jesseClicksForYou(bool, bonus, multiplier) {
                if(bool === true){
                   Math.round(score = score + bonus * multiplier ** 1.5);
                }
                document.getElementById("score").innerHTML = score.toLocaleString();
            }

            function ClicksForYou() {
                
                if(isWindmillClicked === true) {
                    jesseClicksForYou(isWindmillClicked, 2, multiplier);
                    console.log("why");
                    CPPS = Math.round(2 * multiplier ** 1.5);
                    isWindmillClicked = true;
                    document.getElementById("windmillhit").className = "uninvisibleWindmill";
                }
                else {
                    console.log("yay");
                }
                document.getElementById("score").innerHTML = score.toLocaleString();
                document.getElementById("CPPS").innerHTML = CPPS.toLocaleString();
                console.log(isWindmillClicked);
                if(isSlimeGunClicked === true) {
                    jesseClicksForYou(isSlimeGunClicked, 50, slimeGunMultiplier);
                    console.log("why");
                    CPPS = CPPS + Math.round(50 * slimeGunMultiplier ** 1.5);
                    isSlimeGunClicked = true;
                    document.getElementById("slimegunhit").className = "uninvisibleWindmill";
                }
                if(isGiraffeClicked === true) {
                    jesseClicksForYou(isGiraffeClicked, 500, giraffeMultiplier);
                    console.log("why");
                    CPPS = CPPS + Math.round(500 * giraffeMultiplier ** 1.5);
                    isGiraffeClicked = true;
                    document.getElementById("giraffehit").className = "uninvisibleWindmill";
                }
            }
            function normalStuff() {
                document.getElementById("score").innerHTML = score.toLocaleString();
                document.getElementById("CPPS").innerHTML = CPPS.toLocaleString();
                score = Math.round(score);
                if (score >= 2147483647) {
                    if (isSwordClicked === false) {
                        document.getElementById('swordButtonText').innerHTML = 'Sword Costs: 2,147,483,647';
                    }
                }
                if (score >= 100) {
                    if (isWindmillClicked === false) {
                        document.getElementById('windmillButtonText').innerHTML = 'Windmills: 0 Costs: 250';
                    }
                }
                if (multiplier == 1) {
                    document.getElementById('windmillButtonText').innerHTML = 'Windmills: 1 Costs: 187.5';
                }
                if (isWindmillClicked === true) {
                    document.getElementById('windmillButtonText').innerHTML = 'Windmills: ' + multiplier + ' Costs: ' + Math.round(250 * 1.15 ** multiplier).toLocaleString();
                }
                if (score >= 1000) {
                    if (isSlimeGunClicked === false) {
                        document.getElementById('slimeGunButtonText').innerHTML = 'Slime Guns: 0 Costs: 10,000';
                    }
                }
                if (isSlimeGunClicked === true) {
                    document.getElementById('slimeGunButtonText').innerHTML = 'Slime Guns: ' + slimeGunMultiplier + ' Costs: ' + Math.round(10000 * 1.15 ** slimeGunMultiplier).toLocaleString();
                }
                if (score >= 10000) {
                    if (isGiraffeClicked === false) {
                        document.getElementById('giraffeButtonText').innerHTML = 'Giraffes: 0 Costs: 100,000';
                    }
                }
                if (isGiraffeClicked === true) {
                    document.getElementById('giraffeButtonText').innerHTML = 'Giraffes: ' + giraffeMultiplier + ' Costs: ' + Math.round(100000 * 1.15 ** giraffeMultiplier).toLocaleString();
                }
                if (isSwordClicked === true) {
                    $.ajax(
                        {url: 'includes/savejesse.inc.php',type: 'POST',
                        data:{'myScore': 0,'myWindmills': 0, 'mySlimeGuns':0, 'myGiraffes': 0, 'myJesseEnd': isSwordClicked}
                        }).done(function(data) {console.log(data);});
                    window.location.href = "cutscene/cutscene1.php";
                }
            }
            function windmillButtonFunction() {
                if  (multiplier > 0) 
                {
                    if(score > Math.round(250 * 1.15 ** multiplier))
                    {
                        isWindmillClicked = true; 
                        score = score - Math.round(250 * 1.15 ** multiplier); 
                        multiplier++; 
                        document.getElementById('windmillButtonText').innerHTML = 'Windmills: ' + multiplier + ' Costs: ' + Math.round(250 * 1.15 ** multiplier).toLocaleString();
                        }
                } 
                else 
                {
                    if(score > 250)
                    {
                        isWindmillClicked = true; 
                        score = score - 250; 
                        multiplier++; 
                        document.getElementById('windmillButtonText').innerHTML = 'Windmills: ' + multiplier + ' Costs: 250';
                    }
                }
            }
            function slimeGunButtonFunction() {
                if  (slimeGunMultiplier > 0) 
                {
                    if(score > Math.round(10000 * 1.15 ** slimeGunMultiplier))
                    {
                        isSlimeGunClicked = true; 
                        score = score - Math.round(10000 * 1.15 ** slimeGunMultiplier); 
                        slimeGunMultiplier++; 
                        document.getElementById('slimeGunButtonText').innerHTML = 'Slime Guns: ' + slimeGunMultiplier + ' Costs: ' + Math.round(10000 * 1.15 ** slimeGunMultiplier).toLocaleString();
                        }
                } 
                else 
                {
                    if(score > 10000)
                    {
                        isSlimeGunClicked = true; 
                        score = score - 10000; 
                        slimeGunMultiplier++; 
                        document.getElementById('slimeGunButtonText').innerHTML = 'Slime Guns: ' + slimeGunMultiplier + ' Costs: 11,500';
                    }
                }
            }
            function giraffeButtonFunction() {
                if  (giraffeMultiplier > 0) 
                {
                    if(score > Math.round(100000 * 1.15 ** giraffeMultiplier))
                    {
                        isGiraffeClicked = true; 
                        score = score - Math.round(100000 * 1.15 ** giraffeMultiplier); 
                        giraffeMultiplier++; 
                        document.getElementById('giraffeButtonText').innerHTML = 'Giraffes: ' + slimeGunMultiplier + ' Costs: ' + Math.round(100000 * 1.15 ** giraffeMultiplier).toLocaleString();
                        }
                } 
                else 
                {
                    if(score > 100000)
                    {
                        isGiraffeClicked = true; 
                        score = score - 100000; 
                        giraffeMultiplier++; 
                        document.getElementById('giraffeButtonText').innerHTML = 'Giraffes: ' + giraffeMultiplier + ' Costs: 115,000';
                    }
                }
            }
            function swordButtonFunction() {
                if (isSwordClicked === false){
                    if (score >= 2147483647) {
                        isSwordClicked = true;
                        score = score - 2147483647;
                    }
                }
                else {
                    alert("why are you doing this?");
                }
            }
        </script>
        
    </body>
<html>