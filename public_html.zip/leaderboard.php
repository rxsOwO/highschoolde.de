<!DOCTYPE html>
<html>
    <head>
        <title>leaderboard</title>
        <link rel="shortcut icon" type="image/png" href="jesse.png"/>
        <meta name="viewport" content="width=device_width, initial-scale=1.0">
        <style>td,
th {
    border: 1px solid rgb(190, 190, 190);
    padding: 10px;
}

td {
    text-align: center;
}

tr:nth-child(even) {
    background-color: #eee;
}

th[scope="col"] {
    background-color: #696969;
    color: #fff;
}

th[scope="row"] {
    background-color: #d7d9f2;
}

caption {
    padding: 10px;
    caption-side: bottom;
}
h2 {
    text-align:center;
}
table {
    border-collapse: collapse;
    border: 2px solid rgb(200, 200, 200);
    letter-spacing: 1px;
    font-family: sans-serif;
    font-size: .8rem;
    width: 60%;
    float:none;
    margin-left: 20%;
    margin-right: 20%;
}
@media screen and (max-width: 600px){
    table {
        width:100%;
        margin: 0;
    }
}
</style>
    </head>
  
    <body>
        <h2 style="font-family: Arial, Helvetica, sans-serif;">Leaderboard</h2>
        <table>
            <tr>
                <th scope="col">Ranking</td>
                <th scope="col">Username</td>
                <th scope="col">Score</td>
                <th scope="col">SP Per/Sec</td>
            </tr>
        <?php
        
            /* Connection Variable ("Servername",
            "username","password","database") */
            require_once 'includes/dbh.inc.php';
            
            /* Mysqli query to fetch rows 
            in descending order of marks */
            $result = mysqli_query($conn, "SELECT usersUid, usersScore, usersWindmills, usersSlimeGuns, usersGiraffes FROM users ORDER BY usersScore DESC");
            $rank = 1;
            if (mysqli_num_rows($result)) {
                while ($row = mysqli_fetch_assoc($result)) {
                    $row['usersScore'] = number_format($row['usersScore']);
                    $row['usersCPPS'] = number_format(round(2 * $row['usersWindmills'] ** 1.5 + 50 * $row['usersSlimeGuns'] ** 1.5 + 500 * $row['usersGiraffes'] ** 1.5));
                    echo "<tr><th scope='row'>{$rank}</td>
                        <th>{$row['usersUid']}</th>
                        <th>{$row['usersScore']}</th>
                        <th>{$row['usersCPPS']}</th></tr>";
                    
                    $rank++;
                }
            }
        ?>
        </table>

    </body>
</html>