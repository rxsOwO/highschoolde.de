<?php
session_start();

    
    $data = isset($_REQUEST['myScore'])?$_REQUEST['myScore']:"";
    $windmillData = isset($_REQUEST['myWindmills'])?$_REQUEST['myWindmills']:"";
    $slimeGunData = isset($_REQUEST['mySlimeGuns'])?$_REQUEST['mySlimeGuns']:"";
    $giraffeData = isset($_REQUEST['myGiraffes'])?$_REQUEST['myGiraffes']:"";
    $jesseEndData = isset($_REQUEST['myJesseEnd'])?$_REQUEST['myJesseEnd']:"";
    $userid = $_SESSION["userid"];


    require_once 'dbh.inc.php';
    require_once 'functions.inc.php';
if (isset($_SESSION['useruid'])) {
    $cool = saveJesseEnd($conn, $userid, $data, $windmillData, $slimeGunData, $giraffeData, $jesseEndData);
    echo $cool;
}
else {
    header("location: ../login.php?error=notloggedin");
    exit();
}