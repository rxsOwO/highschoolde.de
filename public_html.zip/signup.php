<?php

?>

<html>
    <head>
        <title>sign up</title>
        <link rel="stylesheet" href="styles.css?v=<?php echo time(); ?>">
        <link rel="shortcut icon" type="image/png" href="jesse.png"/>
    </head>
    <body>
        <header class="mainHeaderAcc">
        <h1 style="margin-top: 2.5%;">sign up :)</h1>
        </header>
        <hr>
        <form action="includes/signup.inc.php" method="post">
            <input type="text" name="uid" placeholder="username">
            <input type="password" name="pwd" placeholder="password">
            <button type="submit" name="submit">Sign Up</button>
        </form>    
        <?php
            if (isset($_GET["error"])) {
                if ($_GET["error"] == "emptyinput") {
                    echo "<p class='errortext'>you forgot something</p>";
                }
                else if ($_GET["error"] == "invaliduid") {
                    echo "<p class='errortext'>invalid username</p>";
                }
                else if ($_GET["error"] == "usernametaken") {
                    echo "<p class='errortext'>username taken</p>";
                }
                else if ($_GET["error"] == "stmtfailed") {
                    echo "<p class='errortext'>something went wrong</p>";
                }
                else if ($_GET["error"] == "none") {
                    echo "<p class='successtext'>you successfully signed up</p>";
                }
            }
        ?>
    </body>

<html>

